<?php
session_start();
ob_start();
$konek=mysqli_connect("localhost","absn8143_userabsensi","User4bsensi")or die('koneksigagal');
mysqli_select_db($konek,"absn8143_absensi") or die("gagal");
?>
